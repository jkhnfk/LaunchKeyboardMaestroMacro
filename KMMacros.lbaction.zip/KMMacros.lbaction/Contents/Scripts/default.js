function executeMacro(argument) {
    LaunchBar.hide();
    if (argument != undefined) {
        switch (1) {
            case LaunchBar.options.alternateKey:
                LaunchBar.executeAppleScript('tell application id "com.stairways.keyboardmaestro.engine" to do script "' + argument + '" with parameter "LaunchBarOption"')
                break;
        
            default:
                LaunchBar.executeAppleScript('tell application id "com.stairways.keyboardmaestro.engine" to do script "' + argument + '"');
                break;
        }

    };
}

function openApplication(argument) {
    LaunchBar.hide();
    if (argument != undefined) {
        LaunchBar.executeAppleScript('tell application id "com.stairways.keyboardmaestro.engine" to do script "980E9EE8-E536-4034-9A56-D24444DD9CDD" with parameter "'+ argument + '"');
    };
}

function run(input) {
// var output=File.readJSON ('/Users/jkhnfk/Movies/LB.json');
//vat LBAll=File.readJSON ('/Users/jkhnfk/Movies/LBAll.json');
// var a=JSON.parse(input.replace('"[', "[").replace(']"', "]").replace(/\\/g,""));
// var a=JSON.parse(input.replace('{"[', "[").replace(']"}', "]").replace(/\\/g,""));
// a=LaunchBar.alert(typeof(input)+input);
// a=input;
return JSON.parse(input);
//var result = output.push(LBAll);
//LaunchBar.alert(typeof(output));
//  return output;
}